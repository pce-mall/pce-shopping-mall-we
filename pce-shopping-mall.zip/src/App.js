import React, { useState } from "react";
import { auth, db } from "./firebase";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from "firebase/auth";
import { collection, addDoc } from "firebase/firestore";

function App() {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [cart, setCart] = useState([]);
  const [search, setSearch] = useState("");

  // Sample Products
  const products = [
    { id: 1, name: "Blue Shoes", price: 200, img: "https://via.placeholder.com/150/0000FF" },
    { id: 2, name: "Green Shirt", price: 150, img: "https://via.placeholder.com/150/008000" },
    { id: 3, name: "Black Bag", price: 300, img: "https://via.placeholder.com/150/000000" }
  ];

  const filtered = products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));

  const register = () => {
    createUserWithEmailAndPassword(auth, email, password)
      .then(res => setUser(res.user))
      .catch(err => alert(err.message));
  };

  const login = () => {
    signInWithEmailAndPassword(auth, email, password)
      .then(res => setUser(res.user))
      .catch(err => alert(err.message));
  };

  const logout = () => {
    signOut(auth);
    setUser(null);
  };

  const addToCart = (p) => setCart([...cart, p]);
  const removeFromCart = (id) => setCart(cart.filter(p => p.id !== id));

  const checkout = async () => {
    if (!user) return alert("Login first!");
    await addDoc(collection(db, "orders"), { user: user.email, cart });
    alert("Order placed successfully!");
    setCart([]);
  };

  return (
    <div style={{ background: "linear-gradient(to right, blue, green, black)", minHeight: "100vh", color: "white", padding: "20px" }}>
      <h1>PCE Shopping Mall</h1>
      
      {!user ? (
        <div>
          <h2>Login / Register</h2>
          <input placeholder="Email" onChange={e => setEmail(e.target.value)} />
          <input placeholder="Password" type="password" onChange={e => setPassword(e.target.value)} />
          <button onClick={login}>Login</button>
          <button onClick={register}>Register</button>
        </div>
      ) : (
        <div>
          <h2>Welcome {user.email}</h2>
          <button onClick={logout}>Logout</button>

          <h3>Search</h3>
          <input placeholder="Search product..." onChange={e => setSearch(e.target.value)} />

          <h3>Products</h3>
          {filtered.map(p => (
            <div key={p.id}>
              <img src={p.img} alt={p.name} />
              <p>{p.name} - ₦{p.price}</p>
              <button onClick={() => addToCart(p)}>Add to Cart</button>
            </div>
          ))}

          <h3>Cart</h3>
          {cart.map((c, i) => (
            <div key={i}>
              {c.name} - ₦{c.price}
              <button onClick={() => removeFromCart(c.id)}>Delete</button>
            </div>
          ))}

          <button onClick={checkout}>Checkout (Paystack Demo)</button>
        </div>
      )}
    </div>
  );
}

export default App;
